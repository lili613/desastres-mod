# Desastres Naturais (Fabric 1.20.1)

Mod com 10 blocos que geram desastres naturais.

## Como usar
- Pegue os blocos na aba criativa "Desastres Naturais" (ou `/give @s desastres:vulcao`).
- Ative: clique direito com a mão vazia, ou dê sinal de redstone ao bloco.
- O bloco é consumido e o desastre começa no lugar dele.

IDs: furacao, tornado, tsunami, extincao, vulcao, megatsunami, tempestade_raios, tempestade_fogo, terremoto, megaterremoto

## Como compilar
1. Com JDK 17 e Gradle 8.6+: `gradle build` -> jar em `build/libs/desastres-1.0.0.jar`
2. Ou suba esta pasta num repositório do GitHub: a aba Actions compila e entrega o .jar como artefato.

Precisa do Fabric Loader e do Fabric API para 1.20.1 na pasta mods.

AVISO: os desastres destroem terreno e construções. Faça backup do mundo.
