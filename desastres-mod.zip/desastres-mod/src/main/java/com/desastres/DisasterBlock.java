package com.desastres;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class DisasterBlock extends Block {
    private final DisasterType type;

    public DisasterBlock(Settings settings, DisasterType type) {
        super(settings);
        this.type = type;
    }

    public DisasterType getType() {
        return type;
    }

    // Clique direito com a mão vazia ativa o desastre.
    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (!player.getStackInHand(hand).isEmpty()) {
            return ActionResult.PASS; // deixa colocar blocos ao lado normalmente
        }
        if (world instanceof ServerWorld serverWorld) {
            world.removeBlock(pos, false);
            DisasterManager.start(serverWorld, pos, type);
        }
        return ActionResult.success(world.isClient);
    }

    // Sinal de redstone também ativa.
    @Override
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, BlockPos sourcePos, boolean notify) {
        if (world instanceof ServerWorld serverWorld && serverWorld.isReceivingRedstonePower(pos)) {
            world.removeBlock(pos, false);
            DisasterManager.start(serverWorld, pos, type);
        }
    }
}
